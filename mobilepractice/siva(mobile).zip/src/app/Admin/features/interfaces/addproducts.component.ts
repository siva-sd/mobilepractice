export interface addProductsrequest
{
    pname:string,

    price:number,

    brand:string, 

    image?:File,
    
    stock_qty:number
}