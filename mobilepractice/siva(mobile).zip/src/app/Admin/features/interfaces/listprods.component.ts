export interface productResponseRequest
{
     pid:number,
     pname: string,
     price: number,
     stock_qty: number,
     availability:string,
     imageurl:string
}