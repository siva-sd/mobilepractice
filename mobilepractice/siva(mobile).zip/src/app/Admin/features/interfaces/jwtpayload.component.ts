export interface tokendecode {
    token:string;
    UId: string;
    Role: string;
    Name:string;
    Email:string;
    [key:string]:any
    // Add other fields as needed
}