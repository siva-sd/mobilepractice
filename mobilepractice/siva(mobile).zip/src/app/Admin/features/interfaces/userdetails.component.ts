export interface userlistrequest
{
    uid:number,
    name:string,
    email:string,
    contact:number,
    role:string,
    password:string,
    token?:string,
    gender:string
}