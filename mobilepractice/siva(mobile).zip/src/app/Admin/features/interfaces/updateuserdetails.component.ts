export interface userUpdate{
    name: string,
    contact:number,
    password: string
}