export interface userOrderReq{

   uid:number,
  pid:number,
  deliv_address:string,
  quantity:number,
  amt:number

}