export interface adduserrequest{
  email: string,
  name: string,
  password:string,
  confirmPassword:string,
  contact:number,
}