import { Component } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class UserNavbarComponent {

}
