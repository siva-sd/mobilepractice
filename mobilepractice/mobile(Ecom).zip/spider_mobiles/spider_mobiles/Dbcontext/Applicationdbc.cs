﻿using Microsoft.EntityFrameworkCore;
using spider_mobiles.Models;

namespace spider_mobiles.Dbcontext
{
    public class Applicationdbc:DbContext
    {
        public Applicationdbc(DbContextOptions<Applicationdbc> options):base(options) 
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<user>().HasData(

                new user { uid=1,Email="admin123@gmail.com",Password="admin123",ConfirmPassword="admin123",
                    Name="Sivasankar",Contact=7338925259,Role="Admin",gender="Male"
                });
                
            modelBuilder.Entity<user>().Property(p => p.Role).HasDefaultValue("User");

            modelBuilder.Entity<Order>().Property(p => p.payment_status).HasDefaultValue("Pending");

            modelBuilder.Entity<Order>().Property(p => p.ord_status).HasDefaultValue("Pending");

            //modelBuilder.Entity<Order>().Property(p => p.ord_date).HasDefaultValue(DateTime.Now); 

            //modelBuilder.Entity<Order>().Property(p => p.Deliv_date).HasDefaultValue(DateOnly.FromDateTime(DateTime.Now.AddDays(5)));

            modelBuilder.Entity<product>().Property(p => p.availability).HasDefaultValue("In stock");
        }

        public DbSet<user> usertab { get; set; }

        public DbSet<product> productstab {  get; set; }

        public DbSet<Order> orderstab { get; set; }
    }
}
