﻿using spider_mobiles.Mapperfiles.DTO;
using spider_mobiles.Models;
using System.Collections;
using UserManagement.DTO;

namespace spider_mobiles.Repository.userrepo
{
    public interface Iuserservice
    {

        user adduser(user u);

        user getuser(int id);

        string getUSerByemail(string email, string pass);

        user Updateuserdet(int id,user ud);

        user Detletedetails(string email);
        bool upd(string email,userpwdupdate user);
    }
}
