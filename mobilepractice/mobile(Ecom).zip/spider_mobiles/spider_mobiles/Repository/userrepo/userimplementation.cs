﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using spider_mobiles.Dbcontext;
using spider_mobiles.Mapperfiles.DTO;
using spider_mobiles.Models;
using System.Collections;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using UserManagement.DTO;

namespace spider_mobiles.Repository.userrepo
{
    public class userimplementation : Iuserservice
    {

        private readonly Applicationdbc _context;
        private readonly IConfiguration _config;
        private readonly IMapper _mapper;
        public userimplementation(Applicationdbc context, IConfiguration config, IMapper mapper) 
        {
            _context = context;
            _config=config;
            _mapper = mapper;
        }
        public user adduser(user u)
        {
            if (UserExists(u.Email) == false)
            {
                _context.usertab.Add(u);
                _context.SaveChanges();
                return u;
            }
            return null;
        }

        public user getuser(int id)
        {
           
           var singleuser=_context.usertab.FirstOrDefault(e=>e.uid==id);
           //var pwd=mail?.Password;  
            if (singleuser != null)
            {
                return singleuser;
            }
            return null;
        }
        public user Updateuserdet(int id, user ud)
        {
            var mail = _context.usertab.FirstOrDefault(e => e.uid==id);

            if (mail == null)
            {
                return null;
            }
            mail.Contact = ud.Contact;
            mail.Name = ud.Name;
            mail.Password = ud.Password;
            _context.SaveChanges();
            return ud;
        }
        public user Detletedetails(string email)
        {
            var mail = _context.usertab.FirstOrDefault(e => e.Email.Contains(email));
            
            if (mail == null)
            {
                return null;
            }
           
            user users = _context.usertab.FirstOrDefault(e => e.uid == mail.uid);
           _context.usertab.Remove(users); 
           _context.SaveChanges();
           return users;
        }

        public bool UserExists(string Email)
        {
            var user = _context.usertab.FirstOrDefault(u => u.Email == Email);
            if (user == null) return false;
            return true;
        }

        public bool upd(string email, userpwdupdate user)
        {
            var getdet=_context.usertab.FirstOrDefault(o=>o.Email == email && o.uid==user.uid);
            if (getdet == null)
            {
                return false;
            }
            getdet.Password = user.Password;
            _context.SaveChanges();
            return true;
            
        }

        public string getUSerByemail(string email, string pass)
        {
            var mail = _context.usertab.FirstOrDefault(e => e.Email.Equals(email));
            var pwd=mail?.Password;  
            if (mail != null && pwd!=null)
            {
                var userdetails=_mapper.Map<UserResponseDTO>(mail); 
                var token = GenerateJwtToken(userdetails);
                return token;
                //return mail;
            }
            return null;
        }




        public string GenerateJwtToken(UserResponseDTO userResDto)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["JWT:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[]
            {
         new Claim("UId",userResDto.uid.ToString()),
         new Claim(ClaimTypes.Email , userResDto.Email),
         new Claim(ClaimTypes.Name , userResDto.Name),
         new Claim(ClaimTypes.Role, userResDto.Role)
     };
            var token = new JwtSecurityToken(
                issuer: _config["JWT:Issuer"],
                audience: _config["JWT:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(60),
                signingCredentials: credentials
                );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
