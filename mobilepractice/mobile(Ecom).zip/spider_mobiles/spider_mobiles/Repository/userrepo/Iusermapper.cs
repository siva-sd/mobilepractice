﻿using spider_mobiles.Mapperfiles.DTO;
using spider_mobiles.Models;
using UserManagement.DTO;

namespace spider_mobiles.Repository.userrepo
{
    public interface Iusermapper
    {
        UserRegisterDTO RegisterDTO(UserRegisterDTO userRegisterDTO);       

           UserResponseDTO getUserRegisterDTOs(int id);
        string getUser(string email,string pass);

        userupdatedto updateuser(int id,userupdatedto us);
        UserResponseDTO deleteuser(string email);

        bool updatepwd(string email,userpwdupdate us);
    }
}
