﻿using AutoMapper;
using spider_mobiles.Dbcontext;
using spider_mobiles.Mapperfiles.DTO;
using spider_mobiles.Models;
using System.Collections;
using UserManagement.DTO;

namespace spider_mobiles.Repository.userrepo
{
    public class usermapper : Iusermapper
    {

        private readonly Iuserservice _userserve;
        private readonly IMapper _map;
        //private readonly Applicationdbc _applicationdbc;
        // Applicationdbc applicationdbc
        public usermapper(Iuserservice userserve,IMapper mapper)
        {
            _userserve = userserve;
            _map = mapper;  
           // _applicationdbc = applicationdbc;
        }
        public UserResponseDTO getUserRegisterDTOs(int id)
        {
            var details = _userserve.getuser(id);
            
            var cust=_map.Map<UserResponseDTO>(details);
            if (cust != null)
            {
                return cust;
                //cust.Id = details.uid;
            }
            return null;
            
        }
        public UserRegisterDTO RegisterDTO(UserRegisterDTO userRegisterDTO)
        {   
            var addu=_map.Map<user>(userRegisterDTO);
            var addeddet=_userserve.adduser(addu);
            return _map.Map<UserRegisterDTO>(addeddet);
        }

        public userupdatedto updateuser(int id,userupdatedto userobj)
        {
            var details = _map.Map<user>(userobj);
            //var users = _map.Map<user>(details);
            var userdetails=_userserve.Updateuserdet(id,details);
            return _map.Map<userupdatedto>(userdetails);
        }
        public UserResponseDTO deleteuser(string email)
        {
            var userdetails = _userserve.Detletedetails(email);
            UserResponseDTO response = _map.Map<UserResponseDTO>(userdetails);
            //response.Id = userdetails.uid;
            return response;
        }

        /* public userpwdupdate updatepwd(string email, userpwdupdate us)
         {
             throw new NotImplementedException();
         }*/

        public bool updatepwd(string email, userpwdupdate us)
        {
            var updatedetails =_userserve.upd(email,us);
            return updatedetails;

         }

        public string getUser(string email, string pass)
        {
            string details = _userserve.getUSerByemail(email,pass);

            //var cust = _map.Map<UserResponseDTO>(details);
            if (details != null)
            {
                return details;
                //cust.Id = details.uid;
            }
            return null;
            
        }
    }
}
