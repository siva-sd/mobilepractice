﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Mobile_Ecom.Mapperfiles.productdto;
using spider_mobiles.Dbcontext;
using spider_mobiles.Mapperfiles.productdto;
using spider_mobiles.Models;

namespace spider_mobiles.Repository.productrepo
{
    public class prodimplementation : Iprodservice
    {

        private readonly Applicationdbc _context;
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _imagefolderpath = "C:\\Users\\E1885\\source\\repos\\spider_mobiles\\spider_mobiles\\wwwroot\\productimages";
        private readonly IWebHostEnvironment _webHostEnvironment;
        public prodimplementation(Applicationdbc context, IMapper mapper, IConfiguration config, IHttpContextAccessor httpContextAccessor
            ,IWebHostEnvironment webhostenvironment)
        {
            _context = context;
            _mapper = mapper;
            _config = config;
            _imagefolderpath = _config.GetValue<string>("ImageFolderPath");
            _httpContextAccessor = httpContextAccessor;
            _webHostEnvironment = webhostenvironment;
        }
        public async Task<productresponse> getproducts(int id)
        {
            var proddet = await _context.productstab.FirstOrDefaultAsync(e => e.pid == id);
            /*if (proddet!=null)
            {
                proddet.pid = id;
            }*/
            return _mapper.Map<productresponse>(proddet);
        }

        public async Task<Productdto> addprod(Productdto prods)
        {
            var prod=_mapper.Map<product>(prods);

            if (prods.image!= null)
            {
                var imageurl = SaveImage(prods.image,prods);
                prod.imageurl = imageurl;
                prods.imageurl = imageurl;
            }
            await _context.productstab.AddAsync(prod);
            await _context.SaveChangesAsync();
            
            return _mapper.Map<Productdto>(prod);
        }

        public string SaveImage(IFormFile imageFile,Productdto prods)
        {
            //var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
           
            var localpath = Path.Combine(_webHostEnvironment.ContentRootPath,"wwwroot/productimages", $"{prods.pname}{Path.GetExtension(imageFile.FileName)}");
            //var filepath = Path.Combine(_imagefolderpath, filename);

            using (var stream = new FileStream(localpath, FileMode.Create))
            {
                imageFile.CopyToAsync(stream);
            }

            return $"{_httpContextAccessor.HttpContext.Request.Scheme}://{_httpContextAccessor.HttpContext.Request.Host}{_httpContextAccessor.HttpContext.Request.PathBase}/wwwroot/productimages/{prods.pname}{Path.GetExtension(imageFile.FileName)}";
        }

        public async Task<List<productresponse>> getproducts()
        {
            var proddet = await _context.productstab.ToListAsync();

            var det= _mapper.Map<List<productresponse>>(proddet) ;
            return det;
        }

        public async Task<bool> deleteprods(int id)
        {
            var proddet= _context.productstab.FirstOrDefault(e=>e.pid==id); 
            if(proddet!=null)
            {
               _context.productstab.Remove(proddet);
               await _context.SaveChangesAsync();
                return true;
            }

            return false;


        }

        public async Task<productupdatedto> updateprod(int id, productupdatedto prods)
        {
            var existing_prod= await _context.productstab.AsNoTracking().FirstOrDefaultAsync(e=>e.pid==id);
            if (existing_prod != null)
            {

                var prod = _mapper.Map<product>(prods);



                if (prods.image != null)
                {
                    var imageurl = UpdsaveImage(prods.image, prods);
                    prod.imageurl = imageurl;
                    prods.imageurl = imageurl;
                }

                prod.pid = id;

                if(prods.stock_qty==0)
                {
                    prod.availability = "Not available";
                }
                if(prods.stock_qty>0)
                {
                    prod.availability = "In stock";
                }
                _context.productstab.Update(prod);
                _context.SaveChanges();


                return _mapper.Map<productupdatedto>(prod);
            }
            return null;
        }
        public string UpdsaveImage(IFormFile imageFile, productupdatedto prods)
        {
            //var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);

            var localpath = Path.Combine(_webHostEnvironment.ContentRootPath, "wwwroot/productimages", $"{prods.pname}{Path.GetExtension(imageFile.FileName)}");
            //var filepath = Path.Combine(_imagefolderpath, filename);

            using (var stream = new FileStream(localpath, FileMode.Create))
            {
                imageFile.CopyToAsync(stream);
            }

            return $"{_httpContextAccessor.HttpContext.Request.Scheme}://{_httpContextAccessor.HttpContext.Request.Host}{_httpContextAccessor.HttpContext.Request.PathBase}/wwwroot/productimages/{prods.pname}{Path.GetExtension(imageFile.FileName)}";
        }

        public async Task<productresponse>getprods(int id)
        {
            var details=await _context.productstab.FirstOrDefaultAsync(e=>e.pid == id);
            if (details == null) { return null; }
            return _mapper.Map<productresponse>(details);

        }

       
    }
}
