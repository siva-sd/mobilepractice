﻿using Mobile_Ecom.Mapperfiles.productdto;
using spider_mobiles.Mapperfiles.productdto;
using spider_mobiles.Models;

namespace spider_mobiles.Repository.productrepo
{
    public interface Iprodservice
    {
        Task<Productdto> addprod(Productdto prods);

        Task<productresponse> getproducts(int id);

        Task<List<productresponse>> getproducts();

        Task<productresponse> getprods(int id);  

        Task<productupdatedto> updateprod(int id,productupdatedto prods);

        Task<bool> deleteprods(int id);

        //string SaveImage(IFormFile imageFile);
    }
}
