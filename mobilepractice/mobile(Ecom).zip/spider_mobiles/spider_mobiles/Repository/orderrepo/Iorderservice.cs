﻿using spider_mobiles.Mapperfiles.orderdto;
using spider_mobiles.Models;

namespace spider_mobiles.Repository.orderrepo
{
    public interface Iorderservice
    {
        orddto addorder(orddto orderobj);

        List<ordresponse> getorders();   
        
        orddto cancel(int id,int pid);

        List<ordresponse> getorddet(int id);
    }
}
