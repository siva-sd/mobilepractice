﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using spider_mobiles.Dbcontext;
using spider_mobiles.Mapperfiles.orderdto;
using spider_mobiles.Models;
using System.Linq;

namespace spider_mobiles.Repository.orderrepo
{
    public class orderimplementation : Iorderservice
    {

        private readonly Applicationdbc _context;
        private readonly IMapper _mapper;
        public orderimplementation(Applicationdbc context, IMapper mapper) 
        {
            _context = context;
            _mapper = mapper;
        }
        public orddto addorder(orddto orderobj)
        {
            var orditem = _mapper.Map<Order>(orderobj);
            var uid = _context.usertab.Find(orderobj.uid);
            var pid = _context.productstab.Find(orderobj.pid);
           
            
            
            if (uid == null || pid == null|| pid.stock_qty==0)
            {
                return null;
            }
            if (pid.stock_qty > 0)
            {
                pid.stock_qty -= orditem.quantity;
                orditem.Total_amount = orditem.quantity * pid.price;
                _context.orderstab.Add(orditem);
               
                int qty=pid.stock_qty;
                if (qty == 0)
                {
                    pid.availability = "Out of stock";
                }
                string avail=pid.availability;
                pid.availability=avail;
                _context.SaveChanges();

            }
            return orderobj;
        }

        

        public List<ordresponse> getorders()
        {
            var orders = _context.orderstab.Include(o=>o.prod).Include(e=>e.users).ToList();
            var items=_mapper.Map<List<ordresponse>>(orders);           
            return items;
        }
        public orddto cancel(int id, int oid)
        {
            var userdet = _context.orderstab.Where(e=>e.uid == id && e.Oid == oid).FirstOrDefault();
            var prod = _context.productstab.FirstOrDefault(e => e.pid == userdet.pid);
            /*var userdet = from orddto in _context.orderstab
                          where orddto.uid == id && orddto.pid == pid
                          select orddto;*/
            if (userdet != null)
            {
                _context.orderstab.Remove(userdet);
                prod.stock_qty += userdet.quantity;
                prod.availability = "In Stock";
                _context.SaveChanges();
                return _mapper.Map<orddto>(userdet);
            }
            return null;
        }

        public List<ordresponse> getorddet(int id)
        {
            var orderobj = _context.usertab.FirstOrDefault(e=>e.uid == id);
            if (orderobj != null)
            {
                var ordobj = _context.orderstab.Include(o=>o.prod).Where(e => e.uid == orderobj.uid).ToList();
                return _mapper.Map <List<ordresponse>>(ordobj);
            }
            return null;
        }
    }
}
