
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using spider_mobiles.Dbcontext;
using spider_mobiles.Repository.orderrepo;
using spider_mobiles.Repository.productrepo;
using spider_mobiles.Repository.userrepo;
using System.Reflection;
using System.Text;
using UserManagement.Mapping;

namespace spider_mobiles
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle


            // adding jwt authentication service
            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = builder.Configuration["JWT:Issuer"],
                    ValidAudience = builder.Configuration["JWT:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Key"]))
                };
            });



            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddDbContext<Applicationdbc>(
                options=>options.UseSqlServer(builder.Configuration.GetConnectionString("Dbconnection"))
                );
            builder.Services.AddAutoMapper(typeof(MapperConfig));
            builder.Services.AddTransient<Iuserservice,userimplementation>();

            builder.Services.AddTransient<Iprodservice,prodimplementation>();
            builder.Services.AddTransient<Iorderservice, orderimplementation>();

            builder.Services.AddTransient<Iusermapper,usermapper>();
            builder.Services.AddTransient<IMapper, Mapper>();
            builder.Services.AddHttpContextAccessor();
            

           /* //to add xml file
            builder.Services.AddCors(options =>
            {

                options.AddPolicy("AllowOrigin",

                    builder =>
                    {
                        builder.WithOrigins(
                                        "http://localhost:4200"
                                        ).AllowAnyHeader() // Specify your Angular app's URL here                           .AllowAnyHeader()
                                         .AllowAnyMethod();



                    });

            });*/
            builder.Services.AddSwaggerGen(c => {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Mobile E_comm",
                    Description = "This is the swagger information",
                    TermsOfService = new Uri("https://example.com/terms"),
                    Contact = new OpenApiContact
                    {
                        Name = "Sivasankar",
                        Email = "Siva@gmail.com",
                        Url = new Uri("https://example.com"),
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Use under OpenApiLicense",
                        Url = new Uri("https://example.com/license"),
                    }
                });
                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }
            app.UseCors(c =>
            {
                c.AllowAnyHeader();
                c.AllowAnyMethod();
                c.AllowAnyOrigin();
            }); // add app.userCors is important  step2   ***  step3 in controller


           

            app.UseAuthentication();
           

            app.UseAuthorization();
            app.UseHttpsRedirection();
            //app.UseRouting();

            //image displaying purpose
            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/productimages")),
                RequestPath = "/wwwroot/productimages"
            });
            app.MapControllers();

            app.Run();
        }
    }
}
