﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace spider_mobiles.Migrations
{
    /// <inheritdoc />
    public partial class mgsiva : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "ord_date",
                table: "orderstab",
                type: "datetime2",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldDefaultValue: new DateTime(2024, 7, 11, 10, 16, 53, 202, DateTimeKind.Local).AddTicks(7907));

            migrationBuilder.AlterColumn<DateOnly>(
                name: "Deliv_date",
                table: "orderstab",
                type: "date",
                nullable: false,
                oldClrType: typeof(DateOnly),
                oldType: "date",
                oldDefaultValue: new DateOnly(2024, 7, 16));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "ord_date",
                table: "orderstab",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(2024, 7, 11, 10, 16, 53, 202, DateTimeKind.Local).AddTicks(7907),
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<DateOnly>(
                name: "Deliv_date",
                table: "orderstab",
                type: "date",
                nullable: false,
                defaultValue: new DateOnly(2024, 7, 16),
                oldClrType: typeof(DateOnly),
                oldType: "date");
        }
    }
}
