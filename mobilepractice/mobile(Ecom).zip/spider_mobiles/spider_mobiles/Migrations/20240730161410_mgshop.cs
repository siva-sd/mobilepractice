﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace spider_mobiles.Migrations
{
    /// <inheritdoc />
    public partial class mgshop : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "gender",
                table: "usertab",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "usertab",
                keyColumn: "uid",
                keyValue: 1,
                column: "gender",
                value: "Male");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "gender",
                table: "usertab");
        }
    }
}
