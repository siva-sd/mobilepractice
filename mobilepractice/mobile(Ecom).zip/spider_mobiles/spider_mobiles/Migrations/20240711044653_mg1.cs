﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace spider_mobiles.Migrations
{
    /// <inheritdoc />
    public partial class mg1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "productstab",
                columns: table => new
                {
                    pid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    price = table.Column<double>(type: "float", nullable: false),
                    Brand = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    stock_qty = table.Column<int>(type: "int", nullable: false),
                    availability = table.Column<string>(type: "nvarchar(max)", nullable: false, defaultValue: "In stock"),
                    imageurl = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_productstab", x => x.pid);
                });

            migrationBuilder.CreateTable(
                name: "usertab",
                columns: table => new
                {
                    uid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Contact = table.Column<long>(type: "bigint", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false, defaultValue: "User")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_usertab", x => x.uid);
                });

            migrationBuilder.CreateTable(
                name: "orderstab",
                columns: table => new
                {
                    Oid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    uid = table.Column<int>(type: "int", nullable: false),
                    pid = table.Column<int>(type: "int", nullable: false),
                    ord_date = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValue: new DateTime(2024, 7, 11, 10, 16, 53, 202, DateTimeKind.Local).AddTicks(7907)),
                    Deliv_date = table.Column<DateOnly>(type: "date", nullable: false, defaultValue: new DateOnly(2024, 7, 16)),
                    deliv_address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ord_status = table.Column<string>(type: "nvarchar(max)", nullable: false, defaultValue: "Pending"),
                    quantity = table.Column<int>(type: "int", nullable: false),
                    Total_amount = table.Column<double>(type: "float", nullable: false),
                    payment_status = table.Column<string>(type: "nvarchar(max)", nullable: false, defaultValue: "Pending")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orderstab", x => x.Oid);
                    table.ForeignKey(
                        name: "FK_orderstab_productstab_pid",
                        column: x => x.pid,
                        principalTable: "productstab",
                        principalColumn: "pid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_orderstab_usertab_uid",
                        column: x => x.uid,
                        principalTable: "usertab",
                        principalColumn: "uid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "usertab",
                columns: new[] { "uid", "Contact", "Email", "Name", "Password", "Role" },
                values: new object[] { 1, 7338925259L, "admin123@gmail.com", "Sivasankar", "admin123", "Admin" });

            migrationBuilder.CreateIndex(
                name: "IX_orderstab_pid",
                table: "orderstab",
                column: "pid");

            migrationBuilder.CreateIndex(
                name: "IX_orderstab_uid",
                table: "orderstab",
                column: "uid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "orderstab");

            migrationBuilder.DropTable(
                name: "productstab");

            migrationBuilder.DropTable(
                name: "usertab");
        }
    }
}
