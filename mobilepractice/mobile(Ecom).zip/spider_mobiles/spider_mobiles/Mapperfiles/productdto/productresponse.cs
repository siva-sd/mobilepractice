﻿namespace spider_mobiles.Mapperfiles.productdto
{
    public class productresponse
    {
        public int pid { get; set; }

        public string pname {  get; set; }  

        public string Brand { get; set; }   
        public double price {  get; set; }

        public int stock_qty { get; set; }

        public string availability { get; set; }

        public string imageurl {  get; set; }   
    }
}
