﻿namespace spider_mobiles.Mapperfiles.productdto
{
    public class Productdto
    {

        public string pname { get; set; }

        public double price { get; set; }

        public string Brand { get; set; } 

        public IFormFile image {  get; set; }
        public string? imageurl { get; set; }

        public int stock_qty { get; set; }

       
    }
}
