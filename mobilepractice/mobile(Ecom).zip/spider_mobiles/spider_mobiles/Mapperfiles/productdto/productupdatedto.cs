﻿namespace Mobile_Ecom.Mapperfiles.productdto
{
    public class productupdatedto
    {
        public int pid { get; set; }

        public string pname { get; set; }

        public double price { get; set; }

        public string Brand { get; set; }

        public int stock_qty { get; set; }

        public string? availability { get; set; }

        public IFormFile image { get; set; }

       public string? imageurl { get; set; }

    }
}
