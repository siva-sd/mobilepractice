﻿using spider_mobiles.Models;
using System.ComponentModel.DataAnnotations;

namespace UserManagement.DTO
{
    public class UserResponseDTO
    {
        [Required]
        public int uid { get; set; }
        public string Email { get; set; } = null!;
        public string Name { get; set; } = null!;
        public long Contact { get; set; } 

        public string Password {  get; set; }   

        public string Role { get; set; } = null!;

        public string gender { get; set; }

    }
}
