﻿namespace spider_mobiles.Mapperfiles.DTO
{
    public class userupdatedto
    {
        
        public string Name { get; set; } = null!;
        public long Contact { get; set; }

        public string Password {  get; set; }   



    }
}
