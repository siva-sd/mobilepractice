﻿using spider_mobiles.Mapperfiles.productdto;
using System.ComponentModel.DataAnnotations.Schema;

namespace spider_mobiles.Mapperfiles.orderdto
{
    public class orddto
    {
        public int? uid {  get; set; }
        public int? pid {  get; set; }

        public string deliv_address {  get; set; }

        public int quantity {  get; set; }
        public DateTime? ord_date { get; set; }

        public DateOnly? Deliv_date { get; set; }

        //public double Total_amount { get; set; }

        //public DateTime ord_date { get; set; }

        //public DateOnly Deliv_date { get; set; }
        //public string ord_status { get; set; }

        //public string payment_status { get; set; }

    }
}
