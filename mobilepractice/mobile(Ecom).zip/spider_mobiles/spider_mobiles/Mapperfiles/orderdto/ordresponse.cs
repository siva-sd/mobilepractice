﻿using spider_mobiles.Mapperfiles.productdto;
using spider_mobiles.Models;
using System.ComponentModel.DataAnnotations.Schema;
using UserManagement.DTO;

namespace spider_mobiles.Mapperfiles.orderdto
{
    public class ordresponse
    {
        public int Oid { get; set; }

        public int uid { get; set; }

        //[ForeignKey("uid")]
        public UserResponseDTO? users { get; set; }

        //public int pid { get; set; }

        //[ForeignKey("pid")]
        public Productdto? prod { get; set; }

        public DateOnly Deliv_date { get; set; }

        public int quantity {  get; set; }  

        public double Total_amount {  get; set; }   
    }
}
