﻿using UserManagement.DTO;
using AutoMapper;
using spider_mobiles.Models;
using spider_mobiles.Mapperfiles.productdto;
using spider_mobiles.Mapperfiles.orderdto;
using spider_mobiles.Mapperfiles.DTO;
using Mobile_Ecom.Mapperfiles.productdto;
namespace UserManagement.Mapping
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<UserRegisterDTO, user>().ReverseMap();
            CreateMap<user,UserResponseDTO>().ReverseMap();
            CreateMap<user, userupdatedto>().ReverseMap();
            

            CreateMap<product,Productdto>().ReverseMap();

            CreateMap<product,productresponse>().ReverseMap();  

            CreateMap<productupdatedto,product>().ReverseMap();

            CreateMap<Order,orddto>().ReverseMap(); 
            CreateMap<Order,ordresponse>().ReverseMap();
           
        }
    }
}
