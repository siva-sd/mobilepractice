﻿using spider_mobiles.Mapperfiles.productdto;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace spider_mobiles.Models
{
    public class Order
    {
        [Key]
        public int Oid { get; set; }

        public int uid { get; set; }

       [ForeignKey("uid")]
        public user? users { get; set; }

        public int pid { get; set; }

        [ForeignKey("pid")]
        public product? prod { get; set; }

        public DateTime ord_date { get; set; }

        public DateOnly Deliv_date {  get; set; }

        public string deliv_address {  get; set; }  

        public string ord_status { get; set; }

        public int quantity {  get; set; }

        public double Total_amount {  get; set; }

        public string payment_status {  get; set; }

        
    }
}
