﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using spider_mobiles.Mapperfiles.DTO;
using spider_mobiles.Models;
using spider_mobiles.Message;
using spider_mobiles.Repository.userrepo;
using UserManagement.DTO;
using Microsoft.AspNetCore.Cors;
using spider_mobiles.Dbcontext;

namespace spider_mobiles.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class usercontroller : ControllerBase
    {



        private readonly Iusermapper _user;
        private readonly Applicationdbc _context;
        public usercontroller(Iusermapper usermap,Applicationdbc context)
        {
            _user = usermap;
            _context = context;
        }

        
        /// <summary>
        /// This is to get the user details with email and pass
        /// </summary>
        /// <param name="email"></param>
        /// <param name="pass"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/[action]/{id:int}")]
        public ActionResult Getuserdetails(int id)
        {

            var userdetails = _user.getUserRegisterDTOs(id);
            return Ok(userdetails);
        }


        [HttpGet]
        [Route("[action]")]
        public ActionResult<IEnumerable<UserResponseDTO>> detailsofuser()
        {
            var details=_context.usertab.ToList();
            
            return Ok(details);
        }

        /// <summary>
        /// this is for login purpose setting the details bu email and pass
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("api/[action]/{email}/{pass}")]
        public ActionResult Getuserdetailsbylogin(string email,string pass)
        {

            var userdetails = _user.getUser(email,pass);
            return Ok(new { Token = userdetails });
        }



        [HttpPost]
        [Route("[action]")]
        public ActionResult addusers(UserRegisterDTO userobj)
        {
            var cust = _user.RegisterDTO(userobj);
            if (cust == null)
            {
                ModelState.AddModelError("User with this ",$" {userobj.Email} already exists");
                return BadRequest(ModelState);
            }
            return Ok(cust);

        }

        //[HttpPut]
        //[Route("{email:alpha}")]

        //public ActionResult updatedetails([FromRoute]string email,userupdatedto userobj)
        //{

        //    var details=_user.updateuser(email,userobj);

        //    if (details == null)
        //    {
        //        return BadRequest(new Apiresponse { Success = false, Message = "Your email no longer exists" });
        //    }
        //    return Ok(new Apiresponse { Success = true, Message = "Your details has been updated successfully" });
            
        //}

        [HttpPut]
        [Route("[action]/{id:int}")]

        public ActionResult updateuserdetails(int id, userupdatedto userobj)
        {

            var details = _user.updateuser(id,userobj);

            if (details == null)
            {
                return BadRequest(new Apiresponse { Success = false, Message = "Your email no longer exists" });
            }
            return Ok(new Apiresponse { Success = true, Message = "Your details has been updated successfully" });

        }


        [HttpPut("Update_user_pwd")]

        public ActionResult updatepass(string email, [FromForm] userpwdupdate userobj)
        {

            var details = _user.updatepwd(email, userobj);
            if(details==false)
            {
                return BadRequest(new Apiresponse { Success=false,Message="Your email no longer exists"});
            }
            return Ok(new Apiresponse { Success = true, Message = "Your password updated successfully" });

        }

        [HttpDelete("{email}")]
        public ActionResult deletedet(string email)
        {

            var details = _user.deleteuser(email);
            return Ok(details);

        }
    }
}
