﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Mobile_Ecom.Mapperfiles.productdto;
using spider_mobiles.Dbcontext;
using spider_mobiles.Mapperfiles.productdto;
using spider_mobiles.Message;
using spider_mobiles.Models;
using spider_mobiles.Repository.productrepo;

namespace spider_mobiles.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class prodController : ControllerBase
    {
        private readonly Iprodservice _prods;
        private readonly Applicationdbc _context;
        public prodController(Iprodservice prods, Applicationdbc context)
        {
            _prods = prods;
            _context = context;
        }


        [HttpGet("{id}")]
        [Authorize]

        public async Task<ActionResult> Get(int id)
        {

            var userdetails = await _prods.getproducts(id);
            return Ok(userdetails);
        }

        [HttpGet]
        [Route("[action]")]
        [Authorize]

        public async Task<ActionResult<IEnumerable<product>>> Get()
        {
            var userdetails = await _prods.getproducts();
            return Ok(userdetails);    
        }

        /*[HttpGet]
        [Route("[action]")]

        public ActionResult<IEnumerable<productresponse>> Getproducts()
        {

            var userdetails = _prods.getproductsforuser();
            return Ok(userdetails);
        }*/

        /*[HttpGet]
        [Route("[action]")]
        //[Authorize]
        public async Task <ActionResult<IEnumerable<productresponse>>> Getproductsforuser()
        {

            var userdetails = await _prods.getproducts();
            return Ok(userdetails);
        }*/

        [HttpPost]
        [Route("[action]")]
        [Authorize(Roles ="Admin")]

        public async Task<ActionResult> addproducts(Productdto prodobj)
        {

            //var user=_context.usertab.FirstOrDefault(e=>e.Email == email);
            //if (user != null)
            //{
            //    if (user.Role == "Admin" && pass==user.Password)
            //    {
            var prod = await _prods.addprod(prodobj);
            return Ok(prod);
            //    }
            //}
            //ModelState.AddModelError("You cannot have ", "that rights to add products");
            //return BadRequest(ModelState);
        }

        [HttpDelete("{id:int}")]
        //[Authorize(Roles ="Admin")]
        public async Task<ActionResult> deleteproucts(int id )
        {
            bool details = await _prods.deleteprods(id);

            if (details)
            {
                return Ok(new Apiresponse { Success = true, Message = "product deleted successfuly" });
            }
            return NotFound(new Apiresponse { Success = false, Message = "product Not Found" });


        }

        [HttpPut("{pid:int}")]
        [Authorize(Roles ="Admin")]
        public async Task<ActionResult> updateproductdetails(int pid,productupdatedto prodobj)
        {
            var prod = await _prods.updateprod(pid,prodobj);
            return Ok(prod);

        }

       /* [HttpGet("{id}")]
        public ActionResult getprodsbyid(int id)
        {

            var details = _prods.getprods(id);

            if (details!=null)
            {
                return Ok(details);
            }
            return NotFound(new Apiresponse { Success = false, Message = "product Not Found" });


        }*/
    }
}
