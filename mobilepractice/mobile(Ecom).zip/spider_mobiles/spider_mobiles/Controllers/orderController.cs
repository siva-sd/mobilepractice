﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using spider_mobiles.Dbcontext;
using spider_mobiles.Mapperfiles.orderdto;
using spider_mobiles.Message;
using spider_mobiles.Models;
using spider_mobiles.Repository.orderrepo;

namespace spider_mobiles.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class orderController : ControllerBase
    {
        private readonly Iorderservice _ords;
        private readonly Applicationdbc _context;
        public orderController(Iorderservice ord, Applicationdbc context) 
        {
            _ords = ord;    
            _context = context;
        }

        [HttpGet]
        [Route("[action]")]

        public ActionResult<IEnumerable<ordresponse>> Getorders()
        {
           
                    var userdetails = _ords.getorders().ToList();
                    return Ok(userdetails);
        }

        [HttpPost("{uid}/{pid}")]

        public ActionResult addorders(int uid,int pid,[FromForm] orddto ordobj)
        {
            //var userdet=_context.usertab.FirstOrDefault(e=>e.Email==email);
            //if (userdet == null)
            //{
                //return BadRequest(new Apiresponse { Success = false, Message = "You are not having an account to order" });
            //}
            ordobj.uid = uid;
            ordobj.pid = pid; 
            ordobj.ord_date = DateTime.Now;
            ordobj.Deliv_date= DateOnly.FromDateTime(DateTime.Now.AddDays(5));
            if (ordobj.quantity > 0)
            {
                var prod = _ords.addorder(ordobj);
                return Ok(prod);
            }
            else
            {
                return BadRequest("not founf");
            }
           
        }

        [HttpDelete]
        [Route("[action]/{oid}/{uid}")]
        public ActionResult cancelorder([FromRoute]int oid,[FromRoute]int uid)
        {
            var cancelled = _ords.cancel(oid,uid);
            if (cancelled == null)
            {
                return BadRequest(new Apiresponse { Success=false,Message="You haven't purchased anything"});
            }
            return Ok(new Apiresponse { Success=true,Message="Your order has been successfully cancelled"});
        }

        [HttpGet("{id:int}")]

        public ActionResult getuserorders(int id)
        {

            var userdetails = _ords.getorddet(id);
            if (userdetails != null)
            {
                return Ok(userdetails);
            }
            return BadRequest(new Apiresponse {Success=false,Message="You haven't ordered anything"});
        }
    }
}
