﻿namespace spider_mobiles.Message
{
    public class Apiresponse
    {
        public bool Success {  get; set; }  

        public string Message { get; set; } 
    }
}
